#여기에다가
#호출하면 기능하게.


from flask import Blueprint, render_template, url_for
from werkzeug.utils import redirect

from pybo.models import Question #models파일에서 question함수.
#사용방법은 거의 비슷하나 앞과 다르게 app이 아니라 blueprint를 사용함
#앞에서 이파일?을 호출해서 쓰면되는거임!
bp = Blueprint('main',__name__,url_prefix='/')#main기능을하는 bp함수.

#127.0.0.1:5000/hell0..->->__init__py실행->blueprint인 mainview를 가서 내용찍힘!
@bp.route('/hello')
def hello_pybo():
    return 'Hello, Pybo!'

###하이라이트
@bp.route('/')
def index():
    return redirect(url_for('question._list'))

#init파일에 길게 작성하는게 아니라 bp로 필요한 기능들을 구성해놓아 등록만해놓고 사용함!
#이제 question_list.html템플릿 파일을 만들어야겟지?
@bp.route('/detail/<int:question_id>/')
def detail(question_id):
    question = Question.query.get_or_404(question_id)
    return render_template('question/question_detail.html', question=question)
#이제 question_detail.html을 만들어야.
