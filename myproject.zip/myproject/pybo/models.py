#3주차(2-04)
#db가 필수로 필요.데이터베이스 사용방법!!!.sql쿼리 일일이 보다 자동으로 써주는 orm 있다.
from pybo import db

#question모델 생성
class Question(db.Model):
    id = db.Column(db.Integer, primary_key=True) #primarykey지정해줘야
    subject = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text(), nullable=False)
    create_date = db.Column(db.DateTime(), nullable=False)

#answer모델 생성
class Answer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    question_id = db.Column(db.Integer, db.ForeignKey('question.id', ondelete='CASCADE'))#ForeignKey
    question = db.relationship('Question', backref=db.backref('answer_set'))#ForeignKey제약조건:퀘스쳔 모델서가져온다..
    content = db.Column(db.Text(), nullable=False)
    create_date = db.Column(db.DateTime(), nullable=False)

#지금위의 두 테이블 적용->기존의 디비를 변경하는거니까.. cmd에 flask db migrate
#init초기화->migrate적용->upgrade실행
