##2주차1차시(1-06~2-03)
# 이 코드는 Flask를 사용해 웹 브라우저에서 '/' 경로로 접속했을 때
# 'Hello, Pybo!'라는 메시지를 반환하는 간단한 웹 애플리케이션을 만든 거야.
from flask import Flask #flask쓸거당
from flask_migrate import Migrate #db수정갱신버전업 함수 있음
from flask_sqlalchemy import SQLAlchemy #sql로변경

import config

db = SQLAlchemy()
migrate = Migrate()

def create_app():
    app = Flask(__name__) #flask앱을 개발할거야라고 알려줌.네임은 변수명
    app.config.from_object(config)

    # ORM
    db.init_app(app)
    migrate.init_app(app, db)
    from . import models

    # 블루프린트
    from.views import main_views, question_views, answer_views
    app.register_blueprint(main_views.bp) #뒤파일의 bp를 등록한다!
    app.register_blueprint(question_views.bp)
    app.register_blueprint(answer_views.bp)
    return app
#이랬을땐 암것도 못함 cmd창에서..
#1.myproject
#2.우리가 개발한 pybo모듈을 끌어다 보여줘야.:set FLASK_APP=pybo
#3.플라스크 서버띄우라는 명령어:flask run(warning은 무시.컨트롤씨하면 나감)
#4.나간 후 set FLASK_ENV=development(개발중임을 표시해야된대..)
#5.flask run 하면 127.0.0.1:5000 가 나오고 이제 성공~(댕신기)
#6.이걸 매일 치고 들어갈수는없으니 만들어논 배치파일에 넣어두자.(set FLASK_APP=pybo set FLASK_ENV=development)

#이제 클릭을 해서 다른거 나오는거 써주면 됨
#주소 바뀌는거 approute로. 뭐하라고 함수정의 쭉.
###근데..모듈화 중요.기능별로 독립적인 파일로 만들어야!!(쓸때는 호출해서)
###FLASK에서 모듈화기능하는 BLUEPRINT 제공.
# APLICATION FACTORY:초기에 호출하면 반드시 먼저 뜰것
